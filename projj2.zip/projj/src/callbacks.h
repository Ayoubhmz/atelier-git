#include <gtk/gtk.h>


void
on_accueil_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_afficher_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_supprimer_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_chercher_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_alarme_clicked                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_modifier_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_ajouter_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_retourner_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_add_clicked                         (GtkButton       *button,
                                        gpointer         user_data);

void
on_retourner1_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_afficher1_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_retourner2_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_actualiser_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_Actualiser_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button3_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button5_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview3_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button6_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_check_id_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_aj_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_check_id_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_chercher_etudiant_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_mod_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_actualiser_etudiant_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_technicien_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_nutritionniste_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_agent_restaurant_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_agent_foyer_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_admin_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_principale_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview3_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_refresh_clicked                     (GtkButton       *button,
                                        gpointer         user_data);
