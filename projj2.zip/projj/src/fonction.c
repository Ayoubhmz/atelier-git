#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <time.h>
#include <stdbool.h>
#include <errno.h>

#include "fonction.h"



enum
{
	ENOM,
	EPRENOM,
	EUSERNAME,
	EPASSWORD,
	EROLE,
	EIDENTIFIANT,
	EJOUR,
	EMOIS,
	EANNEE,
	EGENDER,
	EFIELD,
	COLUMNS
};



void ajouter(utilisateurs a)  //ayoub
{
FILE* f=NULL;
f=fopen("user.txt","a+");
if(f!=NULL)
{
fprintf(f,"%s %s %s %s %s %s %d %d %d %s %s\n",a.nom,a.prenom,a.username,a.password,a.role,a.identifiant,a.dob.jour,a.dob.mois,a.dob.annee,a.gender,a.field);

fclose(f);
}
else printf("impossible d'ouvrir le fichier \n");
}
int verif(char username[])
{
	FILE *f=NULL;
	f=fopen("user.txt","r");
	int trouve=1;
	utilisateurs a;
	if(f!=NULL)
	{
		while(fscanf(f,"%s %s %s %s %s %s %d %d %d %s  %s\n",a.nom,a.prenom,a.username,a.password,a.role,a.identifiant,&a.dob.jour,&a.dob.mois,&a.dob.annee,a.gender,a.field)!=EOF)
		{	
			if (strcmp(a.username,username)==0)
			{
				trouve=0;
			}
		}
fclose(f);
	}
return trouve;
}
void supprimer(char username[]) //ayoub
{
utilisateurs a;


FILE *f , *g;
    f=fopen("user.txt","r");
    g=fopen("dumpp.txt","a");
   if(f!=NULL || g!=NULL)
{
while(fscanf(f,"%s %s %s %s %s %s %d %d %d %s %s\n",a.nom,a.prenom,a.username,a.password,a.role,a.identifiant,&a.dob.jour,&a.dob.mois,&a.dob.annee,a.gender,a.field)!=EOF){
if (strcmp(a.username,username)!=0)
fprintf(g,"%s %s %s %s %s %s %d %d %d %s  %s\n",a.nom,a.prenom,a.username,a.password,a.role,a.identifiant,a.dob.jour,a.dob.mois,a.dob.annee,a.gender,a.field);
}
fclose(f);
fclose(g);
remove("user.txt");
rename("dumpp.txt","user.txt");
}
}
void modifier(char search[],char ch1[],char ch2[],char ch3[],char ch4[])  //ayoub
{
utilisateurs a;
FILE* f;
FILE* k;
f=fopen("user.txt","r");
k=fopen("temp.txt","a");

if(f!=NULL || k!=NULL)
{
while(fscanf(f,"%s %s %s %s %s %s %d %d %d %s  %s\n",a.nom,a.prenom,a.username,a.password,a.role,a.identifiant,&a.dob.jour,&a.dob.mois,&a.dob.annee,a.gender,a.field)!=EOF)
{
if(strcmp(a.username,search)==0)
{

fprintf(k,"%s %s %s %s %s %s %d %d %d %s %s \n",ch1,ch2,ch3,ch4,a.role,a.identifiant,a.dob.jour,a.dob.mois,a.dob.annee,a.gender,a.field);}

else
fprintf(k,"%s %s %s %s %s %s %d %d %d %s  %s\n",a.nom,a.prenom,a.username,a.password,a.role,a.identifiant,a.dob.jour,a.dob.mois,a.dob.annee,a.gender,a.field);
}
fclose(f);
fclose(k);
remove("user.txt");
rename("temp.txt","user.txt");
}
}

void rechercher(GtkWidget *liste,char username[]) //ayoub
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
utilisateurs z;
store=NULL;
FILE *f;
store=gtk_tree_view_get_model(liste);
if (store==NULL)
{
	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("Nom",renderer,"text",ENOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes("Prenom",renderer,"text",EPRENOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes("nom d'utilisateur",renderer,"text",EUSERNAME,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes("Mot de passe",renderer,"text",EPASSWORD,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes("Role",renderer,"text",EROLE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes("Identifiant",renderer,"text",EIDENTIFIANT,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer=gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Jour",renderer,"text",EJOUR,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer=gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Mois",renderer,"text",EMOIS,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer=gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Annee",renderer,"text",EANNEE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes("Sexe",renderer,"text",EGENDER,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes("Section",renderer,"text",EFIELD,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	}
store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_STRING,G_TYPE_STRING);
f=fopen("user.txt","r");
if (f=!NULL)
{
	f=fopen("user.txt","a+");
   while(fscanf(f,"%s %s %s %s %s %s %d %d %d %s %s\n",z.nom,z.prenom,z.username,z.password,z.role,z.identifiant,&z.dob.jour,&z.dob.mois,&z.dob.annee,z.gender,z.field)!=EOF)
		{
			if (strcmp(z.username,username)==0)
{
			gtk_list_store_append(store,&iter);
			gtk_list_store_set(store,&iter,ENOM,z.nom,EPRENOM,z.prenom,EUSERNAME,z.username,EPASSWORD,z.password,EROLE,z.role,EIDENTIFIANT,z.identifiant,EJOUR,z.dob.jour,EMOIS,z.dob.mois,EANNEE,z.dob.annee,EGENDER,z.gender,EFIELD,z.field,-1);
		}
} 
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
g_object_unref(store);
}
}
void afficher(GtkWidget *liste) //ayoub
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;

	char nom[100];
	char prenom[100];
	char username[100];
	char password[100];
	char role[100];
	char identifiant[100];
	Date dob;
	char gender[100];
	char field[100];
	utilisateurs a;
	store=NULL; 
	
	FILE *f;

	store=gtk_tree_view_get_model(liste);

	if (store==NULL)
	{

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("Nom",renderer,"text",ENOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes("Prenom",renderer,"text",EPRENOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes("Nom d'utilisateur",renderer,"text",EUSERNAME,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes("Mot de passe",renderer,"text",EPASSWORD,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes("Role",renderer,"text",EROLE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes("Identifiant",renderer,"text",EIDENTIFIANT,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer=gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Jour",renderer,"text",EJOUR,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer=gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Mois",renderer,"text",EMOIS,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer=gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Annee",renderer,"text",EANNEE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes("Sexe",renderer,"text",EGENDER,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes("Section",renderer,"text",EFIELD,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	}
store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_STRING,G_TYPE_STRING);
f=fopen("user.txt","r");

	if(f==NULL)
	{
		return;
	}
	else
	{
		f = fopen("user.txt","a+");
		while(fscanf(f,"%s %s %s %s %s %s %d %d %d %s  %s\n",a.nom,a.prenom,a.username,a.password,a.role,a.identifiant,&a.dob.jour,&a.dob.mois,&a.dob.annee,a.gender,a.field)!=EOF)
		{
			gtk_list_store_append(store,&iter);
						gtk_list_store_set(store,&iter,ENOM,a.nom,EPRENOM,a.prenom,EUSERNAME,a.username,EPASSWORD,a.password,EROLE,a.role,EIDENTIFIANT,a.identifiant,EJOUR,a.dob.jour,EMOIS,a.dob.mois,EANNEE,a.dob.annee,EGENDER,a.gender,EFIELD,a.field,-1);
		}
		fclose(f);
		gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
		g_object_unref(store);
	}

	







}
void afficher1(GtkWidget *list) //ayoub
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

store=NULL;
FILE *f,*f1;
int day,sensor,hour,alarm;
char type[50];

store=gtk_tree_view_get_model(list);
if (store==NULL)
{
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("DAY",renderer,"text",0,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(list),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("HOUR",renderer,"text",1,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(list),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("SENSOR",renderer,"text",2,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(list),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("ALARM",renderer,"text",3,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(list),column);

}
store=gtk_list_store_new(4,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_STRING);
f=fopen("mouvement.txt","r");
f1=fopen("fumee.txt","r");
if (f!=NULL)
{
f=fopen("mouvement","a+");
   while(fscanf(f,"%d %d %d %d",&day,&hour,&sensor,&alarm)!=EOF)
{
if(alarm==1)
{
strcpy(type,"mouvement");
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,0,day,1,hour,2,sensor,3,type,-1);
}
gtk_tree_view_set_model(GTK_TREE_VIEW(list),GTK_TREE_MODEL(store));
g_object_unref(store);
}
}
if(f1!=NULL)
{
	f1=fopen("fumee.txt","a+");
	while(fscanf(f1,"%d %d %d %d",&day,&hour,&sensor,&alarm)!=EOF)
	{
		if(alarm==1)
		{
			strcpy(type,"fumee");
			gtk_list_store_append(store,&iter);
			gtk_list_store_set(store,&iter,0,day,1,hour,2,sensor,3,type,-1);
		}
	}
	fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(list),GTK_TREE_MODEL(store));
g_object_unref(store);
}
}


















